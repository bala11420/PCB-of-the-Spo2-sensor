# Accuracy and limits

## What this design does not claim

No SpO2 sensor is accurate in every situation, and this design does not claim accuracy. I have no measurements from it.

Evidence from independent studies of certified oximeters:
- In a comparison against arterial blood samples, three of four commercial oximeters had a root mean square error above 3% during any motion,
  against 1.8% for the stationary control, and low perfusion increased the error.
  https://pubmed.ncbi.nlm.nih.gov/29200008/
- A study of three commercial devices lists low perfusion, motion, skin pigmentation, anemia, dyes, nail polish and ambient light as factors
  that can affect accuracy, and all three degraded during motion.
  https://link.springer.com/content/pdf/10.1007/s10877-023-01029-x.pdf

I did not find a guaranteed SpO2 accuracy figure for the MAX30102, so I do not quote one.

## What the design can do

- The AFE4490 reports electrical faults exactly (open or shorted LED or photodiode, cable faults).
- Weak signal, saturation, noise and motion must be decided in software from the raw ADC values, with thresholds set from real recordings.
- The SpO2 percentage is always an estimate that depends on calibration.
- The product line should stay: "Bench appliance. Not for real care."

## How I would measure accuracy

Compare the readings with a reference oximeter on several people, at rest, with movement, with cold fingers, and with different skin tones.
A formal accuracy claim would need controlled testing against arterial blood samples, which is outside this project.
