# Chip selection

Prices and status below were seen on 14 November 2026 and can change. Check the links before relying on them.

## Candidates

| | AFE4490 (TI) | MAX30102 (Analog Devices) | MAX86916 (Analog Devices) |
|---|---|---|---|
| Type | Analog front end only. LEDs, photodiode and probe are separate | Module with LEDs, photodiode and electronics in one package | Optical sensor module |
| Interface to the Pi | SPI plus GPIO | I2C | I2C |
| Status | TI lists it as active | ADI lists it as in production, but one distributor page lists a MAX30102 part number (EFD+) as no longer manufactured. Verify before designing in | ADI lists it as recommended for new designs |
| Fault reporting | Diagnostics for open or shorted photodiode and LED, cable faults (nine fault types, 11 flags) | None that I found | Not checked |
| Package | VQFN-40, 6 mm x 6 mm | Small module, breakout boards widely available | Not checked |
| Breadboard friendly | No, needs a custom PCB | Yes, via breakout boards | No |
| Price seen | Lion Circuits: 2,400.96 for 1 piece, 1,939.71 at 10, 1,682.17 at 100, 1,579.17 at 500. The page did not show a currency symbol | Not checked | About $7.56 each at 1,000 pieces on the ADI page (listing, check) |

TI features used in the decision: 22-bit ADC, ambient-light cancellation, programmable LED current ranges, receiver supply 2.0 to 3.6 V,
transmitter supply 3.0 to 5.25 V, integrated fault diagnostics.

## Decision

I chose the **AFE4490** for this design.

Reasons:
1. The diagnostics module gives real, exact reasons for electrical faults (open LED, shorted photodiode), so the device does not have to guess a "sensor fault" status.
2. The front end is built for pulse oximetry, with a low-noise receive path and ambient-light cancellation.
3. The chip is small (6 mm x 6 mm), so the circuit can fit on a compact board that sits on the Pi header.
4. I choose the LEDs and the probe, so the design is not tied to one module.

## Trade-offs I accept

- The chip alone costs far more than a MAX30102 breakout board, and the product also needs a probe, a crystal and a custom PCB.
- It cannot be tested on a breadboard. It needs a PCB, soldering a 40-pin QFN, and a probe.
- There is much more firmware work: register setup, timing control, reading diagnostics.
- It does not fix motion, skin tone or calibration. See `accuracy_and_limits.md`.

## What would change my mind

If the unit cost must stay close to a MAX30102 module, or if I cannot get a suitable probe at a fair price, an integrated
sensor (MAX30102 or its successor) is the better choice, and software would have to detect faults from the signal itself.

## Sources

- TI AFE4490: https://www.ti.com/product/afe4490
- Lion Circuits listing: https://www.lioncircuits.com/parts/AFE4490RHAT
- ADI MAX30102: https://www.analog.com/products/MAX30102
- ADI MAX86916: https://www.analog.com/en/products/MAX86916.html
