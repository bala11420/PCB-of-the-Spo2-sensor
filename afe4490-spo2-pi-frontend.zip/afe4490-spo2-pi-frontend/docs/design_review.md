# Design review of my schematic

I checked `hardware/schematic/SCH_Schematic1_2026-11-10.pdf` against the TI datasheet (SBAS602H) and the TI reference
schematic (Figure 131 in the datasheet). An AI assistant helped with the check, and I decided what to change.
Status "open" means not fixed yet.

## Checked and correct

- Pin names and numbers of U1 match the datasheet pin table.
- Pi header numbers match the Raspberry Pi 40-pin pinout, and the SPI signals use SPI0 (MOSI, MISO, SCLK, CE0).
- BG has 2.2 uF to ground, TX_REF has 2.2 uF, VCM has 10 nF through a series resistor.
- Do-not-connect pins 5, 6 and 10 are left open. Unused outputs 30, 34 and 35 are marked as no connect.
- EP and all ground pins go to ground.
- 10 k pull-ups on AFE_PDN# and RESET#.
- 18 pF crystal load capacitors match the value on the TI reference board (the crystal itself must be chosen to match).

## Issues

| # | Issue | Status |
|---|---|---|
| 1 | R1 (VCM series resistor) is labelled 11K. The datasheet and TI reference board use 1 kOhm. Probably a typo | open |
| 2 | No probe connector. INN and INP connect only to C6 (100 pF), TXN and TXP only have net labels, the VCM guard label goes nowhere | open |
| 3 | Decoupling is missing: only one 100 nF (C7, pin 39). The datasheet shows 0.1 uF on pins 11, 31, 33 and 39, and the TI board has 1 uF on LED_DRV_SUP | open |
| 4 | Receiver supplies come straight from the Pi 3V3 pin. Fine for a first prototype, but it is a noisy rail. Consider a low-noise LDO or filtering, and measure | open |
| 5 | Only one ground pin (H1 pin 6) is used. Add more ground pins for the LED and SPI return current | open |
| 6 | Label typo "CEO" should be "CE0" | open |
| 7 | X1 is drawn as a two-terminal crystal. Check that its footprint is a crystal and not the 4-pin oscillator footprint (OSC-SMD_4P). Check the crystal load capacitance against 18 pF | open |
| 8 | The 5 V transmitter supply needs 4.75 to 5.25 V with the default TX_REF settings. A weak Pi power supply can sag below that | open |
| 9 | Firmware: hold RESET# low for at least 1 ms | note |
| 10 | The Pi has default pull-downs on GPIO22 and GPIO27, which form a divider with the 10 k pull-ups. Turn the internal pulls off in software or use a stronger pull-up. Check the BCM2711 datasheet for the real value | note |
| 11 | No ESD protection on probe lines. The TI reference board clamps the cable lines with diodes | open |
| 12 | LED headroom depends on the real probe LED voltage. Recheck it once the probe is chosen | open |

## Not checked

- The PCB layout and pad dimensions.
- The 3D images.
- The probe pinout (only an unverified forum post exists, see `probe_options.md`).
- The exposed pad connection guidance, and any firmware.
