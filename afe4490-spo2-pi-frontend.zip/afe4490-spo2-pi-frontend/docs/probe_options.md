# Finger-clip probe options

Nothing has been bought. Prices were seen on 14 November 2026 and the sellers are not verified.

## Candidate: Nellcor DS-100A family

- TI's reference schematic for the AFE4490 (datasheet Figure 131) labels its probe connector for a Nellcor DS-100A (DB9 connector).
- A forum post gives a pinout in which the two LEDs share pins 2 and 3 in opposite directions, the photodiode is on pins 5 and 9, and the shield is on pin 7.
  This is **unverified**. Check it against a Nellcor or TI document: https://pinouts.ru/forum/index.php?msg=8774
- TI has not confirmed this probe. In a TI forum thread, a user asked about the DS100A, and TI only said its evaluation kit ships with its own tested sensor.
- Variants differ (9-pin OxiMax with a memory chip, older 7-pin). One seller says its 7-pin sensor works in place of some, but not all, DS100A probes.

## Listings seen

| Seller | Price seen | Note |
|---|---|---|
| eBay generic "fit for Nellcor DS-100A" | $15.99 | Unbranded, quality unknown. https://www.ebay.com/itm/314136646363 |
| Primis Medical | $59.95 | Listed as OEM. https://primismedical.com/a/p/products/covidien-nellcor-ds100a-1-adult-reusable-spo2-sensor-pulse-oximetry-probe |
| PartsSource | $145 aftermarket, $173.25 OEM | https://www.partssource.com/parts/nellcor-covidien/DS100A1 |

## Cost note

A branded probe costs far more than a MAX30102 module, so for a low-cost product the probe would have to be sourced in volume.
