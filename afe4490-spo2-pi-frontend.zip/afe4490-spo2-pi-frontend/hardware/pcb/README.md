# PCB layout

Add your PCB layout images here, for example:

- `pcb_top.png`
- `pcb_bottom.png`

Export them from EasyEDA (PCB view). Also add a short note: board size, number of layers, and whether
it is meant to sit on the Raspberry Pi header.

Not reviewed: the PCB layout has not been checked against the datasheet layout guidance
(guarding the photodiode traces, ground returns for the LED current, placement of decoupling).
