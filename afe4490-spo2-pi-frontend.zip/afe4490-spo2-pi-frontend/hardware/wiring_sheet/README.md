# Wiring sheet (AI-drafted reference)

`afe4490_wiring_sheet.png` was drafted by an AI assistant from the datasheet and used as a reference
while drawing my own schematic. It is **not** the final design. In particular:

- It shows a crystal (Y1) with 18 pF load capacitors and a 3.3 V LDO. My schematic takes 3.3 V directly from the Pi.
- It shows a 5-pin probe connector. My schematic has no probe connector yet.
- Values marked with * are starting values, not datasheet values.

Use `hardware/schematic/` for the actual design.
