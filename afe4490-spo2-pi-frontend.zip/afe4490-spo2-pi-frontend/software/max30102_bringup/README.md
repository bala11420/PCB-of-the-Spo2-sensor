# MAX30102 bring-up script (alternative route, untested)

`max30102_bringup.py` reads the part ID, configures the MAX30102 and prints or records raw red and IR values
on a Raspberry Pi (I2C bus 1).

**Status:** written by an AI assistant from memory of the datasheet and tested only against a mock I2C bus.
It has never run on a real sensor. Check every register address and bit value against the official
MAX30102 datasheet before relying on it.

It does not decide any quality states. Those thresholds should come from your own recordings.

Commands: `check`, `live`, `record`. Setup notes are at the top of the script.
