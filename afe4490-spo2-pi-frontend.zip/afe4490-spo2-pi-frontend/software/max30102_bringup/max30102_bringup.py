#!/usr/bin/env python3
"""MAX30102 bring-up script for a Raspberry Pi (I2C bus 1).

Three commands:
  check   - read the part ID and revision to prove which chip is connected
  live    - configure the chip and print raw red/IR values in the terminal
  record  - save raw samples to a CSV file with a label (no finger, light
            touch, firm pressure, motion) for choosing your own thresholds

STATUS: written from memory of the datasheet and tested only against a mock
I2C bus, NOT on real hardware. Check every register address and bit value
against the official MAX30102 datasheet before trusting it.

Setup (Raspberry Pi OS):
  sudo raspi-config        -> Interface Options -> I2C -> Enable, then reboot
  python3 -m venv ~/venv && . ~/venv/bin/activate && pip install smbus2
  i2cdetect -y 1           -> expect address 57
"""
import argparse
import csv
import sys
import time
from datetime import datetime, timezone

from smbus2 import SMBus

ADDR = 0x57
REG_FIFO_WR = 0x04
REG_FIFO_OVF = 0x05
REG_FIFO_RD = 0x06
REG_FIFO_DATA = 0x07
REG_FIFO_CFG = 0x08
REG_MODE = 0x09
REG_SPO2_CFG = 0x0A
REG_LED_RED = 0x0C
REG_LED_IR = 0x0D
REG_REV_ID = 0xFE
REG_PART_ID = 0xFF
EXPECTED_PART_ID = 0x15  # VERIFY in the datasheet

MODE_RESET = 0x40
MODE_SPO2 = 0x03  # red + IR

SAMPLE_RATES = {50: 0, 100: 1, 200: 2, 400: 3, 800: 4, 1000: 5, 1600: 6, 3200: 7}
ADC_RANGES_NA = {2048: 0, 4096: 1, 8192: 2, 16384: 3}
# pulse width in microseconds -> (register code, ADC resolution in bits)
PULSE_WIDTHS = {69: (0, 15), 118: (1, 16), 215: (2, 17), 411: (3, 18)}
LED_STEP_MA = 0.2  # approx. current per register step; VERIFY


class MAX30102:
    def __init__(self, bus_num=1):
        self.bus = SMBus(bus_num)
        self.bits = 18
        self.sample_rate = 100

    def _r(self, reg):
        return self.bus.read_byte_data(ADDR, reg)

    def _w(self, reg, val):
        self.bus.write_byte_data(ADDR, reg, val & 0xFF)

    def ids(self):
        return self._r(REG_PART_ID), self._r(REG_REV_ID)

    def reset(self):
        self._w(REG_MODE, MODE_RESET)
        for _ in range(20):
            time.sleep(0.01)
            if not (self._r(REG_MODE) & MODE_RESET):
                return
        raise RuntimeError("chip did not leave reset")

    @staticmethod
    def _ma_to_code(ma):
        return max(0, min(255, int(round(ma / LED_STEP_MA))))

    def configure(self, sample_rate=100, pulse_us=411, adc_na=4096,
                  red_ma=7.0, ir_ma=7.0):
        pw_code, self.bits = PULSE_WIDTHS[pulse_us]
        self.sample_rate = sample_rate
        self.reset()
        # no sample averaging, FIFO rollover off (so overflow is visible)
        self._w(REG_FIFO_CFG, 0x00)
        self._w(REG_MODE, MODE_SPO2)
        self._w(REG_SPO2_CFG, (ADC_RANGES_NA[adc_na] << 5)
                | (SAMPLE_RATES[sample_rate] << 2) | pw_code)
        self._w(REG_LED_RED, self._ma_to_code(red_ma))
        self._w(REG_LED_IR, self._ma_to_code(ir_ma))
        self.flush()

    def flush(self):
        for reg in (REG_FIFO_WR, REG_FIFO_OVF, REG_FIFO_RD):
            self._w(reg, 0x00)

    def read_samples(self):
        """Return (list of (red, ir), overflowed)."""
        wr = self._r(REG_FIFO_WR) & 0x1F
        rd = self._r(REG_FIFO_RD) & 0x1F
        overflowed = (self._r(REG_FIFO_OVF) & 0x1F) > 0
        count = 32 if overflowed else (wr - rd) & 0x1F
        out = []
        while count > 0:
            n = min(count, 5)  # 5 samples x 6 bytes = 30 bytes per read
            raw = self.bus.read_i2c_block_data(ADDR, REG_FIFO_DATA, n * 6)
            for i in range(n):
                b = raw[i * 6:(i + 1) * 6]
                red = ((b[0] << 16) | (b[1] << 8) | b[2]) & 0x3FFFF
                ir = ((b[3] << 16) | (b[4] << 8) | b[5]) & 0x3FFFF
                out.append((red, ir))
            count -= n
        return out, overflowed

    def full_scale(self):
        return (1 << self.bits) - 1

    def close(self):
        self.bus.close()


def cmd_check(dev, _args):
    part, rev = dev.ids()
    print(f"Part ID: 0x{part:02X}   Revision: 0x{rev:02X}")
    if part != EXPECTED_PART_ID:
        print("Part ID does not match the expected MAX30102 value.")
        return 2
    print("Part ID matches the expected value.")
    return 0


def _configure(dev, a):
    dev.configure(sample_rate=a.rate, pulse_us=a.pulse_us, adc_na=a.adc_na,
                  red_ma=a.red_ma, ir_ma=a.ir_ma)


def cmd_live(dev, a):
    _configure(dev, a)
    print("Raw red/IR values. Ctrl-C to stop.")
    try:
        while True:
            time.sleep(0.25)
            samples, ovf = dev.read_samples()
            if not samples:
                print("no new samples")
                continue
            reds = [s[0] for s in samples]
            irs = [s[1] for s in samples]
            note = ""
            if max(reds) >= dev.full_scale() or max(irs) >= dev.full_scale():
                note += " SATURATED"
            if ovf:
                note += " FIFO-OVERFLOW"
            print(f"n={len(samples):2d} red={reds[-1]:7d} ir={irs[-1]:7d} "
                  f"ir_min={min(irs):7d} ir_max={max(irs):7d}{note}")
    except KeyboardInterrupt:
        print("stopped")
    return 0


def cmd_record(dev, a):
    _configure(dev, a)
    idx = 0
    end = time.monotonic() + a.seconds
    with open(a.out, "a", newline="") as f:
        w = csv.writer(f)
        if f.tell() == 0:
            w.writerow(["sample_index", "utc_read_time", "label", "red", "ir",
                        "fifo_overflow"])
        while time.monotonic() < end:
            time.sleep(0.2)
            samples, ovf = dev.read_samples()
            now = datetime.now(timezone.utc).isoformat()
            for red, ir in samples:
                w.writerow([idx, now, a.label, red, ir, int(ovf)])
                idx += 1
    print(f"saved {idx} samples to {a.out} (label '{a.label}')")
    return 0


def main():
    p = argparse.ArgumentParser(description=__doc__.split("\n")[0])
    p.add_argument("command", nargs="?", default="check",
                   choices=["check", "live", "record"])
    p.add_argument("--bus", type=int, default=1)
    p.add_argument("--rate", type=int, default=100, choices=SAMPLE_RATES)
    p.add_argument("--pulse-us", type=int, default=411, choices=PULSE_WIDTHS,
                   dest="pulse_us")
    p.add_argument("--adc-na", type=int, default=4096, choices=ADC_RANGES_NA,
                   dest="adc_na")
    p.add_argument("--red-ma", type=float, default=7.0, dest="red_ma")
    p.add_argument("--ir-ma", type=float, default=7.0, dest="ir_ma")
    p.add_argument("--label", default="unlabelled")
    p.add_argument("--seconds", type=float, default=10.0)
    p.add_argument("--out", default="samples.csv")
    a = p.parse_args()

    try:
        dev = MAX30102(a.bus)
    except FileNotFoundError:
        print("I2C bus not found. Is I2C enabled in raspi-config?")
        return 1
    try:
        return {"check": cmd_check, "live": cmd_live,
                "record": cmd_record}[a.command](dev, a)
    except OSError as e:
        print(f"I2C error: {e}. Check wiring, power and pull-ups.")
        return 1
    finally:
        dev.close()


if __name__ == "__main__":
    sys.exit(main())
